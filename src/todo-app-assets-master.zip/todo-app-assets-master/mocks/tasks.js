export const tasks = [
  {
    id: '1',
    title: 'Estudar React Native',
    description: 'Fazer a atividade passada na ultima aula',
    done: false,
    data: '2023-03-27 08:00',
  },

  {
    id: '2',
    title: 'Lavar meu Carro',
    description: 'Lavar meu carro no final da tarde',
    done: false,
    data: '2023-03-27 08:15',
  },

  {
    id: '3',
    title: 'Reunião Trabalho',
    description: 'Preparar o material para a reunião de discussão do novo projeto a ser realizado',
    done: true,
    data: '2023-03-27 08:30',
  },

  {
    id: '4',
    title: 'Ir ao Supermercado',
    description: 'Comprar: Açucar, Café e Pão',
    done: false,
    data: '2023-03-27 08:30',
  },
];
